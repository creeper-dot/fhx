#pragma once
#include <string>

namespace Utils {
    void welcomeMessage();
    std::string getUserInput();
}