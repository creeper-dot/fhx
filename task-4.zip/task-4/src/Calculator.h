#pragma once
#include <string>

class Calculator {
public:
    static double calculate(const std::string& expression);
};